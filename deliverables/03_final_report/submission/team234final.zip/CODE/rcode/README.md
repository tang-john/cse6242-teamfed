Before running code, make sure to do the following in the Terminal/R-Interactive:

install.packages("tidyverse")
install.packages("GGally")
install.packages("rpart")
install.packages("caret")

Ensure you change the read_csv line to reflect where you store the csv files being used/created.
