

DESCRIPTION 
------------

  CODE\Data Consolidation and Selection: The CSV file of our final independent variables and label
  
  CODE\data-exploration : Files created as part of our variable exploration phase
  
  CODE\recode: The R source code used to generate plots to assist with variable selection. 
               See the README.md file in this directory for more information.

  CODE\spark_scala_importer: The Apache Spark Scala code used to import data set into SQLite 
               and then clean, transform, and export the data to a CSV file.  The CSV file 
			   gets copied to Azure ML Studio. See the README.md in this folder how to setup
			   your IDE to execute the code.
							     
  CODE\webapp : The Angular Single Page Web (SPA) source code. It is hosted at 
               https://teamfed-project.herokuapp.com/#/landingPage
  
INSTALLATION
------------
  The installation instructions are also at CODE\webapp\README.md.  
  
  We have designed our application so that it can be executed a local PC or on the cloud.  
  The options to run our application are listed below.
  
  Development server (Local Run without Docker)
  ----------------------------------------------------
  Start a command shell
  Navigate to the webapp directory.
  Run the command "npm install" 
  Run the command "npm start"
  Start a browser and navigate to
  http://localhost:8080/\#/landingPage
  
  
  Docker server (Locally run latest code using Docker)
  ----------------------------------------------------
  Launch a command shell
  Navigate to the webapp directory
  Run the command "docker build -t teamfed ."
  Run the command "docker run -p 8080:8080 teamfed" 
  Launch a browser and navigate to 
  http://localhost:8080/\#/landingPage
  
  
  
  Deploy to Heroku (Prod Run)
  ----------------------------------------------------
  Install the HerokuCLI from https://devcenter.heroku.com/articles/heroku-cli
  Run heroku login to create a session to your heroku account.
  Now you can sign into Container Registry heroku container:login.
  Run heroku container:push web -a teamfed-project to create a docker image 
  and push it to our Heroku repository.
  Run heroku container:release web -a teamfed-project to release the 
  latest image and this will update the webapp.
  Run heroku logs --tail -a teamfed-project to see the logs and 
  output from interacting with the webapp.
  Navigate to https://teamfed-project.herokuapp.com/#/landingPage and watch 
  the as the logs change and acknowledge the interaction with the webapp.


  
  
  
EXECUTION
------------
  A demo of our application is at https://teamfed-project.herokuapp.com/#/landingPage
